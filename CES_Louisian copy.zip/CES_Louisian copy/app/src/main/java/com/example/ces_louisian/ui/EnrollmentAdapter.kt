package com.example.ces_louisian.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.ces_louisian.R
import com.example.ces_louisian.model.StudentEnrollment

class EnrollmentAdapter (private var enrollments: List<StudentEnrollment>) :
    RecyclerView.Adapter<EnrollmentAdapter.EnrollmentViewHolder>() {

    class EnrollmentViewHolder (inflater: LayoutInflater, parent: ViewGroup) :
        RecyclerView.ViewHolder(inflater.inflate(R.layout.item_layout, parent, false)) {
        private var nameTextView: TextView? = null
        private var classTextView: TextView? = null

        init {
            nameTextView = itemView.findViewById(R.id.textViewStudentName)
            classTextView = itemView.findViewById(R.id.textViewClassName)
        }

        fun bind(studentEnroll: StudentEnrollment) {
            nameTextView?.text = studentEnroll.studentName
            classTextView?.text = studentEnroll.className
            // Implement any other bindings here=
        }

    }
    fun submitList(list: List<StudentEnrollment>) {
        enrollments = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EnrollmentViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return EnrollmentViewHolder(inflater, parent)
    }

    override fun onBindViewHolder(holder: EnrollmentViewHolder, position: Int) {
        val enrollment = enrollments[position]
        holder.bind(enrollment)
    }

    override fun getItemCount(): Int {
        return enrollments.size
    }

}
