import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.ces_louisian.dao.StudentEnrollmentDao
import com.example.ces_louisian.ui.StudentEnrollmentViewModel

class StudentEnrollmentViewModelFactory(private val studentEnrollmentDao: StudentEnrollmentDao) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(StudentEnrollmentViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return StudentEnrollmentViewModel(studentEnrollmentDao) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
