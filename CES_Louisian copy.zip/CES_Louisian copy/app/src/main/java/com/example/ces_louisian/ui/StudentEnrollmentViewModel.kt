package com.example.ces_louisian.ui

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ces_louisian.dao.StudentEnrollmentDao
import com.example.ces_louisian.model.StudentEnrollment
import kotlinx.coroutines.launch

class StudentEnrollmentViewModel(private val studentEnrollmentDao: StudentEnrollmentDao) : ViewModel(){

    val allStudentEnrollments = studentEnrollmentDao.getAllEnrollments()

    fun insertEnrollment(enrollment: StudentEnrollment) {
        viewModelScope.launch {
            studentEnrollmentDao.insert(enrollment)
            Log.d("Insertion", "Enrollment inserted: $enrollment")
        }
    }
    fun updateItem(enrollment: StudentEnrollment) {
        viewModelScope.launch {
            studentEnrollmentDao.update(enrollment)
        }
    }
//    fun clearDAO(enrollment: StudentEnrollment) {
//        viewModelScope.launch {
//            studentEnrollmentDao.clearAll()
//        }
//    }
}

