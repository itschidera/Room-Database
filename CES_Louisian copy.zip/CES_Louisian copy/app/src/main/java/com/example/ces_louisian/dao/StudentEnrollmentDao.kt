package com.example.ces_louisian.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.ces_louisian.model.StudentEnrollment
import kotlinx.coroutines.flow.Flow

@Dao
interface StudentEnrollmentDao {
    @Insert
    suspend fun insert(item: StudentEnrollment)

    @Query("SELECT * FROM student_enrollments")
    fun getAllEnrollments(): Flow<List<StudentEnrollment>>

    @Update
    suspend fun update(item: StudentEnrollment)

    @Query("DELETE FROM student_enrollments")
    suspend fun clearAll()
}