package com.example.ces_louisian

import StudentEnrollmentViewModelFactory
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.ces_louisian.dao.StudentEnrollmentDao
import com.example.ces_louisian.database.AppDatabase
import com.example.ces_louisian.databinding.ActivityMainBinding
import com.example.ces_louisian.model.StudentEnrollment
import com.example.ces_louisian.ui.StudentEnrollmentViewModel

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var enrollmentViewModel: StudentEnrollmentViewModel
    private lateinit var studentEnrollmentDao: StudentEnrollmentDao

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val database = AppDatabase.getDatabase(applicationContext)
        studentEnrollmentDao = database.studentEnrollmentDao()

        val factory = StudentEnrollmentViewModelFactory(studentEnrollmentDao)
        enrollmentViewModel = ViewModelProvider(this, factory).get(StudentEnrollmentViewModel::class.java)

        // Initialize RecyclerView
        setupListeners() // Set up click listeners
    }


    private fun setupListeners() {
        binding.buttonEnroll.setOnClickListener {
            val studentName = binding.etStudentName.text.toString().trim()
            val className = binding.etClassName.text.toString().trim()
            if (studentName.isNotEmpty() && className.isNotEmpty()) {
                val enrollment = StudentEnrollment(studentName = studentName, className = className)


               // enrollmentViewModel.clearDAO(enrollment)
                enrollmentViewModel.insertEnrollment(enrollment)

                enrollmentViewModel.updateItem(enrollment)


                val intent = Intent(this, MainActivity2::class.java)
                startActivity(intent)
            }
        }
    }

}
