package com.example.ces_louisian.model

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.ces_louisian.dao.StudentEnrollmentDao

@Database(entities = [StudentEnrollment::class], version = 1)
abstract class AppDatabase : RoomDatabase() {
    abstract fun studentEnrollmentDao(): StudentEnrollmentDao
}