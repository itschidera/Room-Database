package com.example.ces_louisian

import StudentEnrollmentViewModelFactory
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.ces_louisian.dao.StudentEnrollmentDao
import com.example.ces_louisian.database.AppDatabase
import com.example.ces_louisian.databinding.ActivityMain2Binding
import com.example.ces_louisian.ui.EnrollmentAdapter
import com.example.ces_louisian.ui.StudentEnrollmentViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity2 : AppCompatActivity() {

    private lateinit var binding: ActivityMain2Binding
    private lateinit var enrollmentViewModel: StudentEnrollmentViewModel
    private lateinit var adapter: EnrollmentAdapter
    private lateinit var studentEnrollmentDao: StudentEnrollmentDao

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMain2Binding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = EnrollmentAdapter(emptyList())
        binding.recyclerViewStudentEnrollments.adapter = adapter
        binding.recyclerViewStudentEnrollments.layoutManager = LinearLayoutManager(this)


        val database = AppDatabase.getDatabase(applicationContext)
        studentEnrollmentDao = database.studentEnrollmentDao()

        val factory = StudentEnrollmentViewModelFactory(studentEnrollmentDao)
        enrollmentViewModel = ViewModelProvider(this, factory).get(StudentEnrollmentViewModel::class.java)

        setupRecyclerView()
    }
    private fun setupRecyclerView() {
        val recyclerView = findViewById<RecyclerView>(R.id.recyclerViewStudentEnrollments)
        val adapter = EnrollmentAdapter(emptyList())
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(this)

        lifecycleScope.launch(Dispatchers.IO) {
            enrollmentViewModel.allStudentEnrollments.collect { enrollments ->
                    Log.d("DatabaseLog", enrollments.toString())
                launch(Dispatchers.Main) {
                    adapter.submitList(enrollments)
                    adapter.notifyDataSetChanged()
                }
            }
        }
    }

}